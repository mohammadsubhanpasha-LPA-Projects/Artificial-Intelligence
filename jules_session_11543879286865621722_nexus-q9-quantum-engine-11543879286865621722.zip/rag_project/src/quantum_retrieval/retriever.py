from typing import List, Dict, Any
import sys
import os

# Add src directory to path to allow absolute imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from quantum_core.entangle import calculate_entanglement_score

def compute_rrf(ranks: List[int], k: int = 60) -> float:
    """Computes Reciprocal Rank Fusion score."""
    score = 0.0
    for rank in ranks:
        score += 1.0 / (k + rank)
    return score

def quantum_rrf_search(
    query_embedding: List[float], 
    doc_embeddings: List[List[float]], 
    bm25_scores: List[float],
    dense_scores: List[float],
    doc_ids: List[str],
    top_k: int = 5
) -> List[Dict[str, Any]]:
    """
    Combines dense scores, BM25 scores, and quantum entanglement scores using RRF fusion.
    Returns top-k documents with quantum score <200ms.
    """
    # 1. Calculate Quantum Entanglement Scores
    quantum_scores = calculate_entanglement_score(query_embedding, doc_embeddings)
    
    # 2. Get ranks for each scoring method
    # Higher score means better rank (lower rank number, starting at 1)
    
    def get_ranks(scores: List[float]) -> List[int]:
        sorted_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
        ranks = [0] * len(scores)
        for rank, original_index in enumerate(sorted_indices, 1):
            ranks[original_index] = rank
        return ranks
        
    bm25_ranks = get_ranks(bm25_scores)
    dense_ranks = get_ranks(dense_scores)
    quantum_ranks = get_ranks(quantum_scores)
    
    # 3. Calculate RRF Fusion Score
    results = []
    for i in range(len(doc_ids)):
        # rrf_score = 1/(k+dense_rank) + 1/(k+bm25_rank) + 1/(k+quantum_rank)
        rrf_score = compute_rrf([dense_ranks[i], bm25_ranks[i], quantum_ranks[i]])
        
        results.append({
            "doc_id": doc_ids[i],
            "rrf_score": rrf_score,
            "quantum_score": quantum_scores[i],
            "bm25_score": bm25_scores[i],
            "dense_score": dense_scores[i]
        })
        
    # 4. Sort and return top-k
    results.sort(key=lambda x: x["rrf_score"], reverse=True)
    return results[:top_k]
