from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from prometheus_client import make_asgi_app
import sys
import os

# Add src directory to path to allow absolute imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from quantum_retrieval.retriever import quantum_rrf_search
from prompts.grounded_answer import MAIN_SYSTEM_PROMPT, GENERATION_PROMPT

app = FastAPI(title="NEXUS-Q9", description="Quantum Agentic Consciousness Engine")

# Add prometheus asgi middleware to route /metrics
metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)

class QueryRequest(BaseModel):
    query: str
    query_embedding: List[float]
    doc_embeddings: List[List[float]]
    bm25_scores: List[float]
    dense_scores: List[float]
    doc_ids: List[str]

@app.post("/query")
async def query_endpoint(request: QueryRequest):
    # Retrieve top-k using Quantum RRF
    results = quantum_rrf_search(
        query_embedding=request.query_embedding,
        doc_embeddings=request.doc_embeddings,
        bm25_scores=request.bm25_scores,
        dense_scores=request.dense_scores,
        doc_ids=request.doc_ids,
        top_k=5
    )
    
    # In a real implementation, we would pass these results to the generation LLM
    # using GENERATION_PROMPT, checking faithfulness, etc.
    # Here we just return the retrieval results.
    return {
        "status": "success",
        "system_prompt": MAIN_SYSTEM_PROMPT,
        "generation_prompt": GENERATION_PROMPT,
        "results": results
    }

@app.get("/health")
def health_check():
    return {"status": "Quantum Engine Online"}
